<h1>Forget Password Email</h1>
   
You can reset password from below link:
<a href="<?php echo e(route('reset.password.get', $token)); ?>">Reset Password</a><?php /**PATH D:\workspace\LatestCore\resources\views/Email/newPasswordMail.blade.php ENDPATH**/ ?>